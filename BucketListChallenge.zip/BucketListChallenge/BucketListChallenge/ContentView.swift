//
//  ContentView.swift
//  BucketListChallenge
//
//  Created by Wood, Aiden - Student on 10/10/24.
//

import SwiftUI
import MapKit

struct ContentView: View {
    
    let eiffel = CLLocationCoordinate2D(
        latitude: 48.8584,
        longitude: 2.2945)
    
    let arc = CLLocationCoordinate2D(latitude: 48.873756, longitude: 2.294946)
    
    let apple = CLLocationCoordinate2D(latitude: 48.872417936504, longitude: 2.301219030088248)
    
    let louvre = CLLocationCoordinate2D(latitude: 48.8606, longitude: 2.3376)
    
    let invalides = CLLocationCoordinate2D(latitude: 48.8565, longitude: 2.3127)
    
    @State var camera: MapCameraPosition = .automatic
    
    var body: some View {
        Map(position: $camera) {
            Marker("Eiffel Tower", systemImage: "star.fill", coordinate: eiffel)
                
            Marker("Arc De Triomphe", systemImage: "building.columns.fill", coordinate: arc)
                .tint(.blue)
            
            Marker("Apple Champs-Élysées", systemImage: "apple.logo", coordinate: apple)
                .tint(.gray)
            
            Marker("Musée du Louvre", systemImage: "paintbrush.pointed.fill", coordinate: louvre)
                .tint(.green)
            
            Marker("Hôtel des Invalides", systemImage: "fireworks", coordinate: invalides)
                .tint(.black)
        }
        .safeAreaInset(edge: .bottom) {
            HStack{
                Button {
                    camera = .region(MKCoordinateRegion(center: eiffel, latitudinalMeters: 200, longitudinalMeters: 200))
                } label: {
                    Text("Eiffel Tower")
                }
                Button {
                    camera = .region(MKCoordinateRegion(center: arc, latitudinalMeters: 200, longitudinalMeters: 200))
                } label: {
                    Text("Arc De Triomphe")
                }
                Button {
                    camera = .region(MKCoordinateRegion(center: apple, latitudinalMeters: 200, longitudinalMeters: 200))
                } label: {
                    Text("Apple Champs-Élysées")
                }
                Button {
                    camera = .region(MKCoordinateRegion(center: louvre, latitudinalMeters: 200, longitudinalMeters: 200))
                } label: {
                    Text("Musée du Louvre")
                }
                Button {
                    camera = .region(MKCoordinateRegion(center: invalides, latitudinalMeters: 200, longitudinalMeters: 200))
                } label: {
                    Text("Hôtel des Invalides")
                }
            }
                .padding(.top)
                .background(.thinMaterial)
        }
        
    }
}

#Preview {
    ContentView()
}
