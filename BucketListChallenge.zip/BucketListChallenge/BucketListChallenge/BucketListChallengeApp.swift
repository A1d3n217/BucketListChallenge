//
//  BucketListChallengeApp.swift
//  BucketListChallenge
//
//  Created by Wood, Aiden - Student on 10/10/24.
//

import SwiftUI

@main
struct BucketListChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
